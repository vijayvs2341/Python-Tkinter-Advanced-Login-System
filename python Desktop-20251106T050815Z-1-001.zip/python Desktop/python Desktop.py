from tkinter import *
from tkinter import messagebox
import sqlite3
import re
import hashlib
from PIL import Image, ImageTk
import random


# Database Setup

con = sqlite3.connect("secure_users.db")
cur = con.cursor()
cur.execute("""
CREATE TABLE IF NOT EXISTS users (
    username TEXT PRIMARY KEY,
    email TEXT,
    password TEXT
)
""")
con.commit()


                                                                # Utility Functions

def hash_password(password):
    """Convert plain password to SHA256 hash"""
    return hashlib.sha256(password.encode()).hexdigest()

def validate_email(email):
    """Basic email format check"""
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

def password_strength(password):
    """Check if password is strong"""
    if len(password) < 6:
        return "Weak"
    elif not re.search("[A-Z]", password) or not re.search("[0-9]", password):
        return "Medium"
    else:
        return "Strong"


# Tkinter Setup

root = Tk()
root.title("Advanced Login System")
root.geometry("450x500")
root.resizable(False, False)


backgrounds = ["bg1.jpg", "bg2.jpg", "bg3.jpg"]

# Choose a random background each time
bg_image = Image.open(random.choice(backgrounds))
bg_image = bg_image.resize((450, 500))
bg_photo = ImageTk.PhotoImage(bg_image)

# Set background label
bg_label = Label(root, image=bg_photo)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)


                                           # Functions for different actions

def clear_entries():
    for e in [username_entry, password_entry]:
        e.delete(0, END)

def open_register():
    root.withdraw()
    register_window()

def open_forgot_password():
    root.withdraw()
    forgot_password_window()

def register_user(username, email, password):
    if not username or not email or not password:
        messagebox.showwarning("Input Error", "All fields are required!")
        return

    if not validate_email(email):
        messagebox.showerror("Invalid Email", "Please enter a valid email address!")
        return

    strength = password_strength(password)
    if strength == "Weak":
        messagebox.showwarning("Weak Password", "Use at least 6 characters.")
        return

    hashed = hash_password(password)
    try:
        cur.execute("INSERT INTO users VALUES (?, ?, ?)", (username, email, hashed))
        con.commit()
        messagebox.showinfo("Success", "Registration Successful!")
    except sqlite3.IntegrityError:
        messagebox.showerror("Error", "Username already exists!")

def login_user():
    username = username_entry.get()
    password = password_entry.get()
    hashed = hash_password(password)

    cur.execute("SELECT * FROM users WHERE username=? AND password=?", (username, hashed))
    user = cur.fetchone()

    if user:
        messagebox.showinfo("Login Success", f"Welcome, {username}!")
        open_dashboard(username)
    else:
        messagebox.showerror("Login Failed", "Invalid username or password!")

def open_dashboard(username):
    dash = Toplevel(root)
    dash.title("Dashboard")
    dash.geometry("400x300")
    dash.resizable(False, False)

    # Background
    bg_image = Image.open(random.choice(backgrounds))
    bg_image = bg_image.resize((400, 300))
    bg_photo = ImageTk.PhotoImage(bg_image)
    bg_label = Label(dash, image=bg_photo)
    bg_label.image = bg_photo
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)

    Label(dash, text=f"Welcome, {username}!", font=("Arial", 18, "bold"), bg="#000000", fg="white").pack(pady=40)
    Button(dash, text="Logout", font=("Arial", 12, "bold"), bg="red", fg="white",
           command=lambda: [dash.destroy(), root.deiconify()]).pack(pady=20)

# ---------------------------------------------------------------
# Register Window
# ---------------------------------------------------------------
def register_window():
    reg = Toplevel(root)
    reg.title("Register")
    reg.geometry("400x500")
    reg.resizable(False, False)

    # Background
    bg_image = Image.open(random.choice(backgrounds))
    bg_image = bg_image.resize((400, 500))
    bg_photo = ImageTk.PhotoImage(bg_image)
    bg_label = Label(reg, image=bg_photo)
    bg_label.image = bg_photo
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)

    Label(reg, text="Register Account", font=("Arial", 20, "bold"), bg="#000000", fg="white").pack(pady=20)

    Label(reg, text="Username", font=("Arial", 12), bg="#000000", fg="white").pack(pady=5)
    username = Entry(reg, font=("Arial", 12), width=30)
    username.pack(pady=5)

    Label(reg, text="Email", font=("Arial", 12), bg="#000000", fg="white").pack(pady=5)
    email = Entry(reg, font=("Arial", 12), width=30)
    email.pack(pady=5)

    Label(reg, text="Password", font=("Arial", 12), bg="#000000", fg="white").pack(pady=5)
    password = Entry(reg, font=("Arial", 12), width=30, show="*")
    password.pack(pady=5)

    Button(reg, text="Register", font=("Arial", 12, "bold"), bg="red", fg="white",
           command=lambda: register_user(username.get(), email.get(), password.get())).pack(pady=20)

    Button(reg, text="Back to Login", font=("Arial", 10, "bold"), bg="gray", fg="white",
           command=lambda: [reg.destroy(), root.deiconify()]).pack(pady=10)

# ---------------------------------------------------------------
# Forgot Password Window
# ---------------------------------------------------------------
def forgot_password_window():
    fp = Toplevel(root)
    fp.title("Forgot Password")
    fp.geometry("400x350")
    fp.resizable(False, False)

    # Background
    bg_image = Image.open(random.choice(backgrounds))
    bg_image = bg_image.resize((400, 350))
    bg_photo = ImageTk.PhotoImage(bg_image)
    bg_label = Label(fp, image=bg_photo)
    bg_label.image = bg_photo
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)

    Label(fp, text="Reset Password", font=("Arial", 20, "bold"), bg="#000000", fg="#61dafb").pack(pady=20)

    Label(fp, text="Username", font=("Arial", 12), bg="#000000", fg="white").pack(pady=5)
    u_entry = Entry(fp, font=("Arial", 12), width=30)
    u_entry.pack(pady=5)

    Label(fp, text="New Password", font=("Arial", 12), bg="#000000", fg="white").pack(pady=5)
    new_pwd = Entry(fp, font=("Arial", 12), width=30, show="*")
    new_pwd.pack(pady=5)

    def reset_password():
        username = u_entry.get()
        new_password = new_pwd.get()
        if not username or not new_password:
            messagebox.showwarning("Error", "All fields required!")
            return
        hashed = hash_password(new_password)
        cur.execute("UPDATE users SET password=? WHERE username=?", (hashed, username))
        if cur.rowcount == 0:
            messagebox.showerror("Error", "Username not found!")
        else:
            con.commit()
            messagebox.showinfo("Success", "Password updated successfully!")
            fp.destroy()
            root.deiconify()

    Button(fp, text="Reset Password", font=("Arial", 12, "bold"), bg="#21ba45", fg="white", command=reset_password).pack(pady=20)
    Button(fp, text="Back", font=("Arial", 10, "bold"), bg="gray", fg="white", command=lambda: [fp.destroy(), root.deiconify()]).pack()


                                                  # Main Login UI

Label(root, text="Secure Login System", font=("Arial", 20, "bold"), bg="#000000", fg="#61dafb").pack(pady=40)

Label(root, text="Username", font=("Arial", 12), bg="#000000", fg="white").pack(pady=5)
username_entry = Entry(root, font=("Arial", 12), width=30)
username_entry.pack(pady=5)

Label(root, text="Password", font=("Arial", 12), bg="#000000", fg="white").pack(pady=5)
password_entry = Entry(root, font=("Arial", 12), width=30, show="*")
password_entry.pack(pady=5)

Button(root, text="Login", font=("Arial", 12, "bold"), bg="#61dafb", fg="black", width=20, command=login_user).pack(pady=15)
Button(root, text="Register", font=("Arial", 12, "bold"), bg="#21ba45", fg="white", width=20, command=open_register).pack(pady=10)
Button(root, text="Forgot Password", font=("Arial", 10, "bold"), bg="gray", fg="white", command=open_forgot_password).pack(pady=10)

root.mainloop()
con.close()
